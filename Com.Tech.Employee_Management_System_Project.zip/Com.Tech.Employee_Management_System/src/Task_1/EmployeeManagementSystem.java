package Task_1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeManagementSystem {
    private static final String file_name = "employee_data.java";
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Add Employee");
            System.out.println("2. View Employees");
            System.out.println("3. Update Employee");
            System.out.println("4. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    viewEmployees();
                    break;
                case 3:
                    updateEmployee();
                    break;
                case 4:
                    System.out.println("Exiting the program.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addEmployee() {
        System.out.print("Enter Employee ID: ");
        int id = scanner.nextInt();

        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter Employee Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Employee Salary: ");
        double salary = scanner.nextDouble();

        Employee employee = new Employee(id, name, salary);

        try (PrintWriter writer = new PrintWriter(new FileWriter(file_name, true))) {
            writer.println(employee.getId() + "," + employee.getName() + "," + employee.getSalary());
            System.out.println("Employee added successfully!");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    private static void viewEmployees() {
        try (BufferedReader reader = new BufferedReader(new FileReader(file_name))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                Employee employee = new Employee(Integer.parseInt(parts[0]), parts[1], Double.parseDouble(parts[2]));
                System.out.println(employee);
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error parsing employee data: " + e.getMessage());
        }
    }

    private static void updateEmployee() {
    	    System.out.print("Enter Employee ID to update: ");
    	    int targetId = scanner.nextInt();

    	    scanner.nextLine(); // Consume the newline character

    	    ArrayList<String> updatedData = new ArrayList<>();
    	    boolean found = false;

    	    try (BufferedReader reader = new BufferedReader(new FileReader(file_name))) {
    	        String line;
    	        while ((line = reader.readLine()) != null) {
    	            String[] parts = line.split(",");
    	            int currentId = Integer.parseInt(parts[0]);

    	            if (currentId == targetId) {
    	                found = true;

    	                System.out.print("Enter new Employee Name: ");
    	                String newName = scanner.nextLine();

    	                System.out.print("Enter new Employee Salary: $");
    	                double newSalary = scanner.nextDouble();

    	                line = currentId + "," + newName + "," + newSalary;
    	                System.out.println("Employee updated successfully!");
    	            }
    	            updatedData.add(line);
    	        }
    	    } catch (IOException e) {
    	        System.out.println("Error reading from file: " + e.getMessage());
    	    } catch (NumberFormatException e) {
    	        System.out.println("Error parsing employee data: " + e.getMessage());
    	    }

    	    if (found) {
    	        try (PrintWriter writer = new PrintWriter(new FileWriter(file_name))) {
    	            for (String updatedLine : updatedData) {
    	                writer.println(updatedLine);
    	            }
    	        } catch (IOException e) {
    	            System.out.println("Error writing to file: " + e.getMessage());
    	        }
    	    } else {
    	        System.out.println("Employee with ID " + targetId + " not found.");
    	    }
    	}

    }

